/**
 * 
 */
package org.deepesh.rest.model;

/**
 * @author dgupta
 *
 */
public class AbstracEntity {

	public AbstracEntity() {
	}
	
	
}
