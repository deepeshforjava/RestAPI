package org.deepesh.rest.company;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * Hello world!
 *
 */

@ApplicationPath("/services")
public class App extends Application {
}
