/**
 * 
 */
package org.deepesh.rest.utils;

/**
 * @author dgupta
 *
 */
public class CompanyCustomException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6738450740774381570L;

}
